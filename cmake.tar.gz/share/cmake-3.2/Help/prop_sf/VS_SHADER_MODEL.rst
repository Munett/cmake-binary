VS_SHADER_MODEL
---------------

Specifies the shader model of a ``.hlsl`` source file. Some shader types can
only be used with recent shader models
