VS_SHADER_TYPE
--------------

Set the VS shader type of a ``.hlsl`` source file.
