CTEST_CONFIGURATION_TYPE
------------------------

Specify the CTest ``DefaultCTestConfigurationType`` setting
in a :manual:`ctest(1)` dashboard client script.
