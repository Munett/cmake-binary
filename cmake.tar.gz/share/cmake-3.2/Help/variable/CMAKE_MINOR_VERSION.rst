CMAKE_MINOR_VERSION
-------------------

Second version number component of the :variable:`CMAKE_VERSION`
variable.
