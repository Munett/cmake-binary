CMAKE_FRAMEWORK_PATH
--------------------

Search path for OS X frameworks used by the :command:`find_library`,
:command:`find_package`, :command:`find_path`, and :command:`find_file`
commands.
