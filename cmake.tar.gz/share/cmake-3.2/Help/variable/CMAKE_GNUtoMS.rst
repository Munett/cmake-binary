CMAKE_GNUtoMS
-------------

Convert GNU import libraries (.dll.a) to MS format (.lib).

This variable is used to initialize the GNUtoMS property on targets
when they are created.  See that target property for additional
information.
