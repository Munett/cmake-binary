PROJECT_SOURCE_DIR
------------------

Top level source directory for the current project.

This is the source directory of the most recent :command:`project` command.
