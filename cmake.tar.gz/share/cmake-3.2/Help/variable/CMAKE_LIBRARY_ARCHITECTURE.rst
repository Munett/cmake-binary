CMAKE_LIBRARY_ARCHITECTURE
--------------------------

Target architecture library directory name, if detected.

This is the value of CMAKE_<lang>_LIBRARY_ARCHITECTURE as detected for
one of the enabled languages.
