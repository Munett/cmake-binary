CMAKE_SCRIPT_MODE_FILE
----------------------

Full path to the -P script file currently being processed.

When run in -P script mode, CMake sets this variable to the full path
of the script file.  When run to configure a CMakeLists.txt file, this
variable is not set.
