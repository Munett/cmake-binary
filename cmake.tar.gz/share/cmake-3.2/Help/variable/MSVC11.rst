MSVC11
------

True when using Microsoft Visual C 11.0

Set to true when the compiler is version 11.0 of Microsoft Visual C.
