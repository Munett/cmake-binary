CMAKE_APPBUNDLE_PATH
--------------------

Search path for OS X application bundles used by the :command:`find_program`,
and :command:`find_package` commands.
