CTEST_GIT_COMMAND
-----------------

Specify the CTest ``GITCommand`` setting
in a :manual:`ctest(1)` dashboard client script.
