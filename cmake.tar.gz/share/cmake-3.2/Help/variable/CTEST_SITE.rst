CTEST_SITE
----------

Specify the CTest ``Site`` setting
in a :manual:`ctest(1)` dashboard client script.
