CTEST_BINARY_DIRECTORY
----------------------

Specify the CTest ``BuildDirectory`` setting
in a :manual:`ctest(1)` dashboard client script.
