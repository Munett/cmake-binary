CMAKE_MACOSX_BUNDLE
-------------------

Default value for MACOSX_BUNDLE of targets.

This variable is used to initialize the MACOSX_BUNDLE property on all
the targets.  See that target property for additional information.
