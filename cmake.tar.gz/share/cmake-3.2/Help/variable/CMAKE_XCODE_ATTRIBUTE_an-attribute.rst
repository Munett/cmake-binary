CMAKE_XCODE_ATTRIBUTE_<an-attribute>
------------------------------------

Set Xcode target attributes directly.

Tell the Xcode generator to set '<an-attribute>' to a given value in
the generated Xcode project.  Ignored on other generators.

See the :prop_tgt:`XCODE_ATTRIBUTE_<an-attribute>` target property
to set attributes on a specific target.
