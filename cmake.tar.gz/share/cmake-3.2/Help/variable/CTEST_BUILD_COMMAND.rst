CTEST_BUILD_COMMAND
-------------------

Specify the CTest ``MakeCommand`` setting
in a :manual:`ctest(1)` dashboard client script.
