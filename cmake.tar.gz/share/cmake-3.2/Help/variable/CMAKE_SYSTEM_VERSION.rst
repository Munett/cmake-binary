CMAKE_SYSTEM_VERSION
--------------------

The OS version CMake is building for.

This variable is the same as :variable:`CMAKE_HOST_SYSTEM_VERSION` if
you build for the host system instead of the target system when
cross compiling.
