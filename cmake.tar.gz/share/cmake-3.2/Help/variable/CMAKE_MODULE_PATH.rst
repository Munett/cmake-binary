CMAKE_MODULE_PATH
-----------------

List of directories to search for CMake modules.

Commands like include() and find_package() search for files in
directories listed by this variable before checking the default
modules that come with CMake.
